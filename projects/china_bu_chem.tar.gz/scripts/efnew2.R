
x = x 
lkm = net$lkm 
tfs = pro 
v = metadata$v[i]
t = metadata$t[i]
f = metadata$f[i] 
standard = std1 
s = metadata$sppm[i]
speed = speed
te = met$Temperature
hu = met$Humidity
h = h$h
yeardet = 2016
p = pol[j]
array = T
