options(encoding = "UTF-8")
library(vein) # vein
library(sf) # spatial data
library(cptcity) # 7120 colour palettes
library(ggplot2) # plots
library(eixport) # create wrfchemi
library(data.table) # faster data.frames

# 2) Traffic ####
print("traffic")
language <- "spanish" # english spanish portuguese
net <- readRDS("network/net.rds")
metadata <- readRDS("config/metadata.rds")
categories <- c("pc", "lcv", "trucks", "bus", "mc") # in network/net.gpkg
veh <- readRDS("config/fleet_age.rds")
verbose <- FALSE
year <- 2024
theme <- "black" # dark clean ink
k_D <- 1
k_G <- 1

ispeed <- TRUE
tfs <- readRDS("config/tfs.rds")
ps <- "ps"
ffs <- "ffs"
capacity <- "capacity"
source("scripts/traffic.R", encoding = "UTF-8")
rm(list = ls())
gc()
