options(encoding = "UTF-8")
Sys.setlocale("LC_TIME", "English") # Windows
library(vein)                     # vein
library(sf)                       # ler dados espaciais
library(data.table)
library(cptcity)                  # 7120 paletas de cores
library(ggplot2)                  # plots
library(magick)

sessionInfo()

# 0 Configuration
# source("config/packages.R")
rota                 <- "config/inventory.xlsx"
readxl::excel_sheets(rota)
metadata             <- readxl::read_xlsx(path = rota, sheet = "metadata")
mileage              <- readxl::read_xlsx(path = rota, sheet = "mileage")
tfs                  <- readxl::read_xlsx(path = rota, sheet = "tfs")
veh                  <- readxl::read_xlsx(path = rota, sheet = "fleet_age")
fuel                 <- readxl::read_xlsx(path = rota, sheet = "fuel")
year                 <- 2020
cores                <- c("black", "red", "green3", "blue", "brown",
                          "magenta", "yellow", "gray", "darkblue")
source("config.R")

# 1) Network ####
net                  <- sf::st_read("network/net.gpkg")
crs                  <- 31983
tit                  <- "Fluxo veicular [veh/h] em São Paulo"
veiculos             <- c("pc", "lcv", "trucks", "bus", "mc") # presentes em network/net.gpkg
source("scripts/net.R")

# 2) Traffic ####
# para ler libre office calc, pode usar readODS::read_ods()
net                 <- readRDS("network/net.rds")
metadata            <- readRDS("config/metadata.rds")
veiculos            <- c("pc", "lcv", "trucks", "bus", "mc") # estão em network/net.gpkg
veh                 <- readRDS("config/fleet_age.rds")
k_D                 <- 1/0.5750815
k_E                 <- 1/0.1355068
k_G                 <- 1/0.1867037
verbose             <- FALSE
year                <- 2020
tit                 <- "Veículos [veh/h] por ano de uso em São Paulo"
tit2                <- "Veículos em São Paulo [%]"
cores               <- c("black", "red", "green3", "blue", "cyan",
                         "magenta", "yellow", "gray", "brown")
source('scripts/traffic.R')

# 3) Estimation #### 
metadata            <- readRDS("config/metadata.rds")
mileage             <- readRDS("config/mileage.rds")
tfs                 <- readRDS("config/tfs.rds")
veh                 <- readRDS("config/fleet_age.rds")
net                 <- readRDS("network/net.rds")
lkm                 <- net$lkm
verbose             <- FALSE
year                <- 2020
cores               <- c("black", "red", "green3", "blue", "brown",
                         "magenta", "yellow", "gray", "darkblue")

# calibração combustivel http://dadosenergeticos.energia.sp.gov.br/portalcev2/intranet/PetroGas/index.html
fuel                <- readRDS("config/fuel.rds")
pol                 <- "FC"
factor_emi          <- 366/31             # convertir estimativa diaria a anual
source('scripts/fuel_eval.R') # repetir ate bater consumo e estimativa

# Estimativa
pol                 <- c("CO",  "NMHC",  "NOx", "CO2",
                         "PM", "NO2")
source('scripts/escapamento.R')

#evaporativas
# temperatura media marco 2020 = 20.8 graus em  Sao Paulo
diurnal_ef          <- "D_10_25"
running_losses_ef   <- "R_10_25"
hot_soak_ef         <- "S_10_25"
source('scripts/evaporativas.R')

# ressuspensao gera PM e PM10
metadata            <- readRDS("config/metadata.rds")
mileage             <- readRDS("config/mileage.rds")
tfs                 <- readRDS("config/tfs.rds")
net                 <- readRDS("network/net.rds")
veh                 <- readRDS("config/fleet_age.rds")
lkm                 <- net$lkm
tf_PC               <- tfs$PC_G
tf_LCV              <- tfs$LCV_G
tf_TRUCKS           <- tfs$TRUCKS_L_D
tf_BUS              <- tfs$BUS_URBAN_D
tf_MC               <- tfs$MC_150_G
sL1                 <- 0.6        # silt [g/m^2] se ADT < 500 (US-EPA AP42) i
sL2                 <- 0.2        # silt [g/m^2] se 500 < ADT < 5000 (US-EPA AP42)
sL3                 <- 0.06       # silt [g/m^2] se 5000 < ADT < 10000 (US-EPA AP42)
sL4                 <- 0.03       # silt [g/m^2] se ADT > 10000 (US-EPA AP42)
source('scripts/ressuspensao.R')


# 4) Post-estimation 500m #### 
net                 <- readRDS("network/net.rds")
pol                 <- c("CO",  "NMHC",  "NOx", "CO2",
                         "PM", "NO2")
g                   <- make_grid(net, 500)
# Number of lat points 207
# Number of lon points 157
crs                 <- 31983
factor_emi          <- 366/31        # convertir estimativa a anual
source('scripts/post.R')

# plots ####
metadata            <- readRDS("config/metadata.rds")
tfs                 <- readRDS("config/tfs.rds")
veh                 <- readRDS("config/fleet_age.rds")
pol                 <- c("CO",  "NMHC",  "NOx", "CO2",
                         "PM", "NO2")
year                <- 2020
factor_emi          <- 366/31       # convertir estimativa diaria a anual
hours               <- 8
bg                  <- "white"
pal                 <- "mpl_viridis"# procura mais paletas com ?cptcity::find_cpt
breaks              <- "quantile"        # "sd" "quantile" "pretty"
tit                 <- "Vehicular emissions in São Paulo"
source('scripts/plots.R')


# geopackages  ####
tfs                 <- readRDS("config/tfs.rds")
# domingo 1 de marzo
hour                <- round(tfs$hour)
hourd               <- format(round(tfs$hour), "%c")
hourd[25:(25+167)]

# 500m ####

# NOx
x                   <- readRDS("post/grids/NOx.rds")
prequ               <- names(x)[25:(25+167)+1]
qu                  <- names(x)[(22*24+2):(22*24+2+167)]
NOx_dfpq            <- rowMeans(st_set_geometry(x, NULL)[prequ])
NOx_dfq             <- rowMeans(st_set_geometry(x, NULL)[qu])
NOx_dif             <- NOx_dfpq - NOx_dfq
NOx_dif_per         <- (NOx_dfpq - NOx_dfq)/NOx_dfpq * 100
dfnox               <- data.frame(NOx_prequ_gkm2h = NOx_dfpq,
                                  NOx_qu_gkm2h = NOx_dfq,
                                  NOx_dif = NOx_dif,
                                  NOx_dif_per)
summary(dfnox)

# NO2
x                   <- readRDS("post/grids/NO2.rds")
prequ               <- names(x)[25:(25+167)+1]
qu                  <- names(x)[(22*24+2):(22*24+2+167)]
NO2_dfpq            <- rowMeans(st_set_geometry(x, NULL)[prequ])
NO2_dfq             <- rowMeans(st_set_geometry(x, NULL)[qu])
NO2_dif             <- NO2_dfpq - NO2_dfq
NO2_dif_per         <- (NO2_dfpq - NO2_dfq)/NO2_dfpq * 100
dfno2               <- data.frame(NO2_prequ_gkm2h = NO2_dfpq,
                                  NO2_qu_gkm2h = NO2_dfq,
                                  NO2_dif = NO2_dif,
                                  NO2_dif_per)
summary(dfno2)

# NMHC
x                   <- readRDS("post/grids/NMHC.rds")
prequ               <- names(x)[25:(25+167)+1]
qu                  <- names(x)[(22*24+2):(22*24+2+167)]
NMHC_dfpq           <- rowMeans(st_set_geometry(x, NULL)[prequ])
NMHC_dfq            <- rowMeans(st_set_geometry(x, NULL)[qu])
NMHC_dif            <- NMHC_dfpq - NMHC_dfq
NMHC_dif_per        <- (NMHC_dfpq - NMHC_dfq)/NMHC_dfpq * 100
dfnmhc              <- data.frame(NMHC_prequ_gkm2h = NMHC_dfpq,
                                  NMHC_qu_gkm2h = NMHC_dfq,
                                  NMHC_dif = NMHC_dif,
                                  NMHC_dif_per = NMHC_dif_per)

summary(dfnmhc)

# NMHCNO2
NMHC_NO2_dfpq       <- NMHC_dfpq/NO2_dfpq
NMHC_NO2_dfq        <- NMHC_dfq/NO2_dfq
NMHC_NO2_dif        <- (NMHC_NO2_dfpq - NMHC_NO2_dfq)
NMHC_NO2_dif_per    <- (NMHC_NO2_dfpq - NMHC_NO2_dfq)/NMHC_NO2_dfpq * 100
dfnmhcno2           <- data.frame(NMHC_NO2_prequ_gkm2h = NMHC_NO2_dfpq,
                                  NMHC_NO2_qu_gkm2h = NMHC_NO2_dfq,
                                  NMHC_NO2_dif = NMHC_NO2_dif,
                                  NMHC_NO2_dif_per = NMHC_NO2_dif_per)

summary(dfnmhcno2)

# NMHCNOx
NMHC_NOx_dfpq       <- NMHC_dfpq/NOx_dfpq
NMHC_NOx_dfq        <- NMHC_dfq/NOx_dfq
NMHC_NOx_dif        <- (NMHC_NOx_dfpq - NMHC_NOx_dfq)
NMHC_NOx_dif_per    <- (NMHC_NOx_dfpq - NMHC_NOx_dfq)/NMHC_NOx_dfpq * 100
dfnmhcnox           <- data.frame(NMHC_NOx_prequ_gkmxh = NMHC_NOx_dfpq,
                                  NMHC_NOx_qu_gkmxh = NMHC_NOx_dfq,
                                  NMHC_NOx_dif = NMHC_NOx_dif,
                                  NMHC_NOx_dif_per = NMHC_NOx_dif_per)

sf500m              <- st_sf(cbind(dfno2, dfnmhc, dfnox,
                                   dfnmhcno2, dfnmhcnox),
                             geometry = x$geometry)
sf500m              <- st_transform(sf500m, 4326)

dir.create("post/geopackages")

st_write(obj = sf500m, 
         dsn = "post/geopackages/gridded500m.gpkg", 
         layer = "sf500m", 
         driver = "GPKG", 
         delete_layer = T)
system("tar -caf post/gridded500m.gpkg.tar.gz post/geopackages/gridded500m.gpkg")

#section 3.1.4 ####
library(magrittr)
summary(sf500m[sf500m$NMHC_prequ_gkm2h > 0, ]$NMHC_prequ_gkm2h) %>% round()
summary(sf500m[sf500m$NMHC_qu_gkm2h != 0, ]$NMHC_qu_gkm2h) %>% round()
wilcox.test(sf500m[sf500m$NMHC_prequ_gkm2h > 0, ]$NMHC_prequ_gkm2h, 
            sf500m[sf500m$NMHC_qu_gkm2h != 0, ]$NMHC_qu_gkm2h)
summary(sf500m[sf500m$NMHC_qu_gkm2h != 0, ]$NMHC_dif) %>% round()
summary(sf500m[sf500m$NMHC_qu_gkm2h != 0, ]$NMHC_dif_per)  %>% round(., 1)

summary(sf500m[sf500m$NO2_prequ_gkm2h != 0, ]$NO2_prequ_gkm2h) %>% round()
summary(sf500m[sf500m$NO2_qu_gkm2h != 0, ]$NO2_qu_gkm2h) %>% round()
wilcox.test(sf500m[sf500m$NO2_prequ_gkm2h != 0, ]$NO2_prequ_gkm2h, 
            sf500m[sf500m$NO2_qu_gkm2h != 0, ]$NO2_qu_gkm2h)
summary(sf500m[sf500m$NO2_prequ_gkm2h != 0, ]$NO2_dif)
summary(sf500m[sf500m$NO2_qu_gkm2h != 0, ]$NO2_dif_per)  %>% round(., 1)

summary(sf500m$NMHC_NO2_prequ_gkm2h) %>% round(.,1)
summary(sf500m$NMHC_NO2_qu_gkm2h) %>% round(., 1)
wilcox.test(sf500m$NMHC_NO2_prequ_gkm2h, 
            sf500m$NMHC_NO2_qu_gkm2h)
summary(sf500m$NMHC_NO2_dif)
summary(sf500m$NMHC_NO2_dif_per) %>% round(., 1)

# wilcoxon


center              <- data.frame(lon = -46.65, lat = -23.56)

sfcenter            <- st_as_sf(center, coords = c("lon", "lat"), crs = 4326)
plot(sfcenter$geometry, axes = T, pch = 16)


cen                 <- st_transform(sfcenter, 31983)

buf                 <- st_transform(st_buffer(cen, 10000), 4326)
plot(sf500m[sf500m$NO2_prequ_gkm2h != 0, ]["NO2_prequ_gkm2h"], 
     lty = 0, 
     breaks = seq(0,max(sf500m$NO2_prequ_gkm2h), by = 100),
     pal = cpt(colorRampPalette = T, rev = T), 
     axes = T,
     main = NULL,
     cex.main=2,
     reset = F)
plot(buf, add = T)

# plots grid 500m####
buffer_sf500m       <- st_intersection(sf500m, buf)

sum(buffer_sf500m$NO2_prequ_gkm2h)
sum(sf500m$NO2_prequ_gkm2h)

plot(buffer_sf500m["NO2_prequ_gkm2h"], axes = T)

summary(buffer_sf500m[buffer_sf500m$NMHC_prequ_gkm2h > 0, ]$NMHC_prequ_gkm2h) %>% round()
summary(buffer_sf500m[buffer_sf500m$NMHC_prequ_gkm2h > 0, ]$NMHC_qu_gkm2h) %>% round()

summary(buffer_sf500m[buffer_sf500m$NO2_prequ_gkm2h > 0, ]$NO2_prequ_gkm2h) %>% round()
summary(buffer_sf500m[buffer_sf500m$NO2_qu_gkm2h > 0, ]$NO2_qu_gkm2h) %>% round()

summary(buffer_sf500m$NMHC_NO2_prequ_gkm2h) %>% round(.,2)
summary(buffer_sf500m$NMHC_NO2_qu_gkm2h) %>% round(.,2)
hist(buffer_sf500m$NMHC_NO2_dif) %>% round(.,2)
summary(buffer_sf500m$NMHC_NO2_dif) %>% round(.,2)


summary(buffer_sf500m[buffer_sf500m$NMHC_prequ_gkm2h > 0, ]$NMHC_dif_per) %>% round()
summary(buffer_sf500m[buffer_sf500m$NO2_prequ_gkm2h > 0, ]$NO2_dif_per) %>% round()
summary(buffer_sf500m$NMHC_NO2_dif_per) %>% round()


png("images/A_NO2_pre_qua_500mt_gkm2h.png", width = 2500, height = 1900, units = "px", res = 300)
plot(sf500m[sf500m$NO2_prequ_gkm2h != 0, ]["NO2_prequ_gkm2h"], 
     lty = 0, 
     breaks = seq(0,max(sf500m$NO2_prequ_gkm2h), by = 100),
     pal = cpt(colorRampPalette = T, rev = T), 
     axes = T,
     main = NULL,
     cex.main=2)
dev.off()

png("images/B_NO2_qua_500mt_gkm2h.png", width = 2500, height = 1900, units = "px", res = 300)
plot(sf500m[sf500m$NO2_qu_gkm2h != 0, ]["NO2_qu_gkm2h"], lty = 0,
     breaks = seq(0,max(sf500m$NO2_prequ_gkm2h), by = 100),
     pal = cpt(colorRampPalette = T, rev = T), 
     # key.pos = NULL,
     axes = T,
     main = NULL,
     cex.main=2)
dev.off()

summary(sf500m$NO2_dif)

png("images/C_NO2_dif_500mt_per_gkm2.png", width = 2500, height = 1900, units = "px", res = 300)
plot(sf500m[sf500m$NO2_qu_gkm2h != 0, ]["NO2_dif_per"], lty = 0,
     breaks = 0:100,
     pal = cpt(colorRampPalette = T, rev = T, pal = "mpl_viridis"),
     axes = T,
     main = NULL,
     cex.main=2)
dev.off()


png("images/D_NMHC_pre_qua_500mt_gkm2.png", width = 2500, height = 1900, units = "px", res = 300)
plot(sf500m[sf500m$NMHC_prequ_gkm2h > 0, ]["NMHC_prequ_gkm2h"], 
     lty = 0, 
     breaks = seq(0,max(sf500m$NMHC_prequ_gkm2h), by = 100),
     pal = cpt(colorRampPalette = T, rev = T), 
     axes = T,
     cex.main=2,
     main = NULL)
dev.off()

png("images/E_NMHC_qua_500mt_gkm2.png", width = 2500, height = 1900, units = "px", res = 300)
plot(sf500m[sf500m$NMHC_qu_gkm2h > 0, ]["NMHC_qu_gkm2h"], lty = 0,
     breaks = seq(0,max(sf500m$NMHC_prequ_gkm2h), by = 100),
     pal = cpt(colorRampPalette = T, rev = T),
     # key.pos = NULL,
     axes = T,
     cex.main=2,
     main = NULL)
dev.off()

png("images/F_NMHC_dif_500mt_per_gkm2.png", width = 2500, height = 1900, units = "px", res = 300)
plot(sf500m[sf500m$NMHC_qu_gkm2h != 0, ]["NMHC_dif_per"], lty = 0,
     breaks = 0:100,
     pal = cpt(colorRampPalette = T, rev = T, pal = "mpl_viridis"),
     axes = T,
     cex.main=2,
     main = NULL)
dev.off()

png("images/G_NMHC_NO2_pre_qua_500mt_gkm2.png", width = 2500, height = 1900, units = "px", res = 300)
plot(sf500m["NMHC_NO2_prequ_gkm2h"], 
     lty = 0, 
     breaks = seq(0,max(sf500m$NMHC_NO2_prequ_gkm2h, na.rm = T), by = 0.001),
     pal = cpt(colorRampPalette = T, rev = T), 
     # key.pos = NULL,
     axes = T,
     cex.main=2,
     main = NULL)
dev.off()

png("images/H_NMHC_NO2_qua_500mt_gkm2.png", width = 2500, height = 1900, units = "px", res = 300)
plot(sf500m["NMHC_NO2_qu_gkm2h"], lty = 0,
     # breaks = seq(0,max(sf500m$NMHC_NO2_prequ_gkm2h, na.rm = T), by = 0.0001),
     pal = cpt(colorRampPalette = T, rev = T), 
     # key.pos = NULL,
     cex.main=2,
     axes = T,
     main = NULL)
dev.off()

hist(sf500m[sf500m$NMHC_NO2_dif >-6000, ]$NMHC_NO2_dif)
summary(sf500m[sf500m$NMHC_NO2_dif >-6000, ]$NMHC_NO2_dif)

png("images/I_NMHC_NO2_dif_per_500mt_gkm2.png", width = 2500, height = 1900, units = "px", res = 300)
plot(sf500m["NMHC_NO2_dif_per"], lty = 0,
     breaks = 0:100,
     pal = cpt(colorRampPalette = T, rev = T, pal = "mpl_viridis"),
     axes = T,
     cex.main=2,
     main = NULL)
dev.off()


a                <- image_append(c(image_read("images/A_NO2_pre_qua_500mt_gkm2h.png"),
                                   image_read("images/B_NO2_qua_500mt_gkm2h.png"),
                                   image_read("images/C_NO2_dif_500mt_per_gkm2.png")),
                                 stack = T)

b                <- image_append(c(image_read("images/D_NMHC_pre_qua_500mt_gkm2.png"),
                                   image_read("images/E_NMHC_qua_500mt_gkm2.png"),
                                   image_read("images/F_NMHC_dif_500mt_per_gkm2.png")),
                                 stack = T)

cc               <- image_append(c(image_read("images/G_NMHC_NO2_pre_qua_500mt_gkm2.png"),
                                   image_read("images/H_NMHC_NO2_qua_500mt_gkm2.png"),
                                   image_read("images/I_NMHC_NO2_dif_per_500mt_gkm2.png")),
                                 stack = T)


image_write(image = image_trim(image_append(c(a, b, cc), stack = F)), 
            path = "images/NO2NMHC500m.png")

# TFS ####
rota                 <- "config/inventory.xlsx"
readxl::excel_sheets(rota)
tfs              <- readxl::read_xlsx(path = rota, sheet = "profiles")
hour             <- readxl::read_xlsx(path = rota, sheet = "tfs")$hour
df <- data.table(profile = c(tfs$Leves1,
                             tfs$caminhao2eixos,
                             tfs$caminhao3eixos,
                             tfs$caminhao4eixos,
                             tfs$total69eixos,
                             tfs$ONIBUSTOTAL,
                             tfs$mc),
                 Vehicles = rep(c("Passenger Cars",
                                  "Light Commercial Vehicles",
                                  "Light Trucks",
                                  "Medium Trucks",
                                  "Heavy Trucks",
                                  "Buses",
                                  "Motorcycles"), 
                                each = nrow(tfs)),
                 Period = c(rep("Other", 24),
                            rep("Pre-Lockdown", 168),
                            rep("Other", 168*2),
                            rep("Lockdown", 168),
                            rep("Other", 24*2)),
                 hour = hour)

df$Vehicles      <- factor(df$Vehicles, 
                           levels = c("Passenger Cars",
                                      "Light Commercial Vehicles",
                                      "Light Trucks",
                                      "Medium Trucks",
                                      "Heavy Trucks",
                                      "Buses",
                                      "Motorcycles"))

df[, perc := 100*profile/sum(profile), by = .(Vehicles)]
df[, sum(perc), by = .(Vehicles)]

p                <- ggplot(df, aes(x = hour,
                                   y = profile,
                                   colour = Period,
                                   group = Vehicles)) +
  # geom_point() +
  labs(x = NULL, 
       y = "[veh/h]",
       title = "Hourly traffic in São Paulo in March 2020 [veh/h]") +
  geom_line(size =1) +
  facet_wrap(~Vehicles, scales = "free_y", ncol = 2) +
  scale_colour_manual("", values = c("blue", "grey", "red"))+
  theme_bw() +
  theme(legend.position = "bottom")
p
png(filename = "images/artesp.png", 
    width = 3000, height =1800, units = "px", res = 300)
print(p)
dev.off()

df$hora          <- hour(df$hour)

dt               <- df[Period %in% c("Pre-Lockdown", "Lockdown")]
dt$Vehicles      <- as.character(dt$Vehicles)
dt$time          <- rep(1:168, 7*2)

dtt              <- dt[, 
                       round(mean(profile, na.rm = T), 2), 
                       by = .(Period, Vehicles)]
dxx              <- vein::long_to_wide(df = dtt, 
                                       column_with_new_names = "Vehicles", 
                                       column_with_data = "V1", 
                                       column_fixed = "Period")
dxx2            <- dxx
lockdown <- dxx[1, 2:ncol(dxx)]
prelockdown <- dxx[2, 2:ncol(dxx)]


(prelockdown - lockdown)/prelockdown*100


dx              <- vein::long_to_wide(df = dt[Vehicles == "Passenger Cars"], 
                                      column_with_new_names = "Period", 
                                      column_with_data = "profile", 
                                      column_fixed = "time")
wilcox.test(dx$Lockdown, dx$`Pre-Lockdown`)

dx              <- vein::long_to_wide(df = dt[Vehicles == "Light Commercial Vehicles"], 
                                      column_with_new_names = "Period", 
                                      column_with_data = "profile", 
                                      column_fixed = "time")
wilcox.test(dx$Lockdown, dx$`Pre-Lockdown`)

dx               <- vein::long_to_wide(df = dt[Vehicles == "Light Trucks"], 
                                       column_with_new_names = "Period", 
                                       column_with_data = "profile", 
                                       column_fixed = "time")
wilcox.test(dx$Lockdown, dx$`Pre-Lockdown`)

dx              <- vein::long_to_wide(df = dt[Vehicles == "Medium Trucks"], 
                                      column_with_new_names = "Period", 
                                      column_with_data = "profile", 
                                      column_fixed = "time")
wilcox.test(dx$Lockdown, dx$`Pre-Lockdown`)

dx              <- vein::long_to_wide(df = dt[Vehicles == "Heavy Trucks"], 
                                      column_with_new_names = "Period", 
                                      column_with_data = "profile", 
                                      column_fixed = "time")
wilcox.test(dx$Lockdown, dx$`Pre-Lockdown`)

dx              <- vein::long_to_wide(df = dt[Vehicles == "Buses"], 
                                      column_with_new_names = "Period", 
                                      column_with_data = "profile", 
                                      column_fixed = "time")
wilcox.test(dx$Lockdown, dx$`Pre-Lockdown`)

dx              <- vein::long_to_wide(df = dt[Vehicles == "Motorcycles"], 
                                      column_with_new_names = "Period", 
                                      column_with_data = "profile", 
                                      column_fixed = "time")
wilcox.test(dx$Lockdown, dx$`Pre-Lockdown`)

