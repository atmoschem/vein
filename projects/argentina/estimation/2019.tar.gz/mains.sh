

Rscript scripts/main_01_config.R         
Rscript scripts/main_02_traffic.R                  
Rscript scripts/main_03_fuel_eval.R          
Rscript scripts/main_04_exhaust.R             
Rscript scripts/main_05_evaporative.R  
Rscript scripts/main_06_wear.R
Rscript scripts/main_07_paved.R
Rscript scripts/main_08_post.R
Rscript scripts/main_09_post_roads.R
Rscript scripts/main_10_post_grid.R
Rscript scripts/main_11_plot.R
Rscript scripts/main_12_mech_spatial.R
Rscript scripts/main_13_mech_spatial_GAS_PM.R
Rscript scripts/main_14_wrf.R
Rscript scripts/merge_industrial_vein.R
