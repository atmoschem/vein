suppressWarnings(file.remove("emi/paved.csv"))

tf_PC <- 1
tf_LCV <- 1
tf_TRUCKS <- 1
tf_BUS <- 1
tf_MC <- 1

# identicar nomes de grupos
nveh <- names(veh)
n_PC <- nveh[grep(pattern = "PC", x = nveh)]
n_LCV <- nveh[grep(pattern = "LCV", x = nveh)]
n_TRUCKS <- nveh[grep(pattern = "TRUCKS", x = nveh)]
n_BUS <- nveh[grep(pattern = "BUS", x = nveh)]
n_MC <- nveh[grep(pattern = "MC", x = nveh)]

# rowSums
soma <- function(PATTERN){
  list.files("veh", ".rds", full.names = T) -> xv
  xpc <- grep(pattern = PATTERN,x = xv,value = T)
  lv  <- lapply(1:length(xpc), function(i){
    def = readRDS(xpc[i])
    rowSums(def,na.rm = T)
  })
  rowSums(do.call('cbind',lv),na.rm = T)
}

PC <- soma('PC')
LCV <- soma('LCV')
TRUCKS <- soma('TRUCKS')
BUS <- soma('BUS')
MC <- soma('MC')

# Fluxo semanal horario vezes veiculo equivalente (veh eq)
vkpc <- temp_fact(q = PC, pro = 1)
vklcv <- temp_fact(LCV, pro = 1)
vkhgv <- temp_fact(TRUCKS, pro = 1)
vkbus <- temp_fact(BUS, pro = 1)
vkmc <- temp_fact(MC, pro = 1)
vk <- vkpc + vklcv + vkmc + vkhgv + vkbus

# calculo ADT
ADT <- (PC + LCV + TRUCKS + BUS + MC)/5
# ADT <- adt(
#    pc = PC,
#    lcv = LCV,
#    hgv = TRUCKS,
#    bus = BUS,
#    mc = MC,
#    p_pc = tf_PC,
#    p_lcv = tf_LCV,
#    p_hgv = tf_TRUCKS,
#    p_bus = tf_BUS,
#    p_mc = tf_MC
# )


# calculo W
W <- aw(
  pc = PC,
  lcv = LCV,
  hgv = TRUCKS,
  bus = BUS,
  mc = MC,
  p_pc = tf_PC,
  p_lcv = tf_LCV,
  p_hgv = tf_TRUCKS,
  p_bus = tf_BUS,
  p_mc = tf_MC
)



pol <- c("PM10", "PM")
k <- c(0.62, 0.15)


for (i in seq_along(metadata$vehicles)) {
  cat(
    "\n", metadata$vehicles[i],
    rep("", max(nchar(metadata$vehicles) + 1) - nchar(metadata$vehicles[i]))
  )
  
  # x <- net[[metadata$vehicles[i]]]
  x  <- readRDS(paste0("veh/", metadata$vehicles[i], ".rds"))
  xx <- rowSums(x,na.rm = T)
  
  q <- temp_fact(q = xx, pro = 1)
  
  for (j in seq_along(pol)) {
    cat(pol[j], " ")
    
    emi <- emis_paved(
      veh = q,
      adt = ADT,
      lkm = lkm,
      k = k[j],
      sL1 = sL1,
      sL2 = sL2,
      sL3 = sL3,
      sL4 = sL4,
      W = W
    )
    
    
    st <- data.table(id = 1:nrow(net),
                     emis = emis, 
                     pollutant = pol[j],
                     veh = metadata$vehicles[i],
                     size = metadata$size[i],
                     fuel = metadata$fuel[i],
                     type_emi = "Paved Roads",
                     date = as.Date(ISOdate(year, month, 1)))
    fwrite(st, "emi/paved.csv", append = T)
    
  }
}

switch(language,
       "portuguese" = message("\n\nArquivos em: /emi/*:"),
       "english" = message("\nFiles in: /emi/*"),
       "spanish" = message("\nArchivos en: /emi/*")
)


switch(language,
       "portuguese" = message("Limpando..."),
       "english" = message("Cleaning..."),
       "spanish" = message("Limpiando...")
)



suppressWarnings(
  rm(
    ADT,
    PC, LCV, TRUCKS, BUS, MC,
    n_PC, n_LCV, n_TRUCKS, n_BUS, n_MC,
    tf_PC, tf_LCV, tf_TRUCKS, tf_BUS, tf_MC,
    emi, g, lkm,
    metadata, tfs, veh,
    net, nveh, pol,
    verbose,
    vk, vkbus, vkhgv, vklcv, vkmc, vkpc, W, x_DF,
    ef_cetesb2, ef_evaps, i, j, k, mileage, name_file_evap, num_vein,
    q, type_emis, vein_version, x, cores, fuel,
    sL1, sL2, sL3, sL4
  )
)