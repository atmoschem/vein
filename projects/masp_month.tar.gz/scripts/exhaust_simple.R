suppressWarnings(file.remove("emi/exhaust.csv"))

# Escapamento ####
switch(language,
       "portuguese" = cat("Estimando emissões\n"),
       "english" = cat("Estimating emissions\n"),
       "spanish" = cat("Estimando emisiones\n")
)



for (i in seq_along(metadata$vehicles)) {
  cat(
    "\n", metadata$vehicles[i],
    rep("", max(nchar(metadata$vehicles) + 1) - nchar(metadata$vehicles[i]))
  )
  
  # x <- net[[metadata$vehicles[i]]]
  x  <- readRDS(paste0("veh/", metadata$vehicles[i], ".rds"))
  xx <- rowSums(x,na.rm = T)
  
  for (j in seq_along(pol)) {
    cat(pol[j], " ")
    
    ef <- ef_cetesb(
      p = pol[j],
      veh = metadata$vehicles[i],
      year = year,
      agemax = ncol(x),
      verbose = verbose,
      scale = scale,
      sppm = sppm
    )[1:40]
    
    # eff <- weighted.mean(ef, veh[[metadata$vehicles[i]]], na.rm = T)
    eff <- weighted.mean(ef, colSums(x,na.rm = T), na.rm = T)
    
    emis <- xx*eff*lkm
    
    st <- data.table(id = 1:nrow(net),
                     emis = emis, 
                     pollutant = pol[j],
                     veh = metadata$vehicles[i],
                     size = metadata$size[i],
                     fuel = metadata$fuel[i],
                     type_emi = "Exhaust",
                     date = as.Date(ISOdate(year, month, 1)))
    fwrite(st, "emi/exhaust.csv", append = T)
  }
  rm(st, emis)
}


switch(language,
       "portuguese" = message("\n\nArquivos em: /emi/*:"),
       "english" = message("\nFiles in: /emi/*"),
       "spanish" = message("\nArchivos en: /emi/*")
)


switch(language,
       "portuguese" = message("Limpando..."),
       "english" = message("Cleaning..."),
       "spanish" = message("Limpiando...")
)

suppressWarnings(
  rm(
    i, j, pol,
    n_PC, n_LCV, n_TRUCKS, n_BUS, n_MC,
    ns, ln, p, df, dl, cores
  )
)

invisible(gc())
