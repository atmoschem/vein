suppressWarnings(file.remove("emi/evaporatives.csv"))

# temperature
te <- met$Temperature
bb <- (0 + 15) / 2
cc <- (10 + 25) / 2
dd <- (20 + 35) / 2

tem <- ifelse(
  te <= bb, "0_15",
  ifelse(
    te > bb & te <= cc, "10_25",
    "20_35"
  )
)

nmonth <- ifelse(nchar(seq_along(te)) < 2,
                 paste0(0, seq_along(te)),
                 seq_along(te)
)

# filtrando veiculos otto
meta_ev <- metadata[metadata$fuel != "D", ]
veh_ev <- meta_ev$vehicles

# checks name
type_emis <- c("Diurnal", "Running Losses", "Hot Soak")
name_file_evap <- c("/DIURNAL_", "/RUNNING_LOSSES_", "/HOT_SOAK_")

ef_d <- paste0("D_", tem)
ef_rl <- paste0("R_", tem)
ef_hs <- paste0("S_", tem)

# plot
n_PC <- metadata[metadata$family == "PC", ]$vehicles
n_LCV <- metadata[metadata$family == "LCV", ]$vehicles[1:4]
n_MC <- metadata[metadata$family == "MC", ]$vehicles

ns <- c(
  "PC", "LCV", "MC",
  "PC", "LCV", "MC",
  "PC", "LCV", "MC"
)
ln <- list(
  n_PC, n_LCV, n_MC,
  n_PC, n_LCV, n_MC,
  n_PC, n_LCV, n_MC
)
laby <- c(
  "g/day", "g/day", "g/day",
  "g/trip", "g/trip", "g/trip",
  "g/trip", "g/trip", "g/trip"
)
ev <- c(
  "DIURNAL", "DIURNAL", "DIURNAL",
  "RUNNING_LOSSES", "RUNNING_LOSSES", "RUNNING_LOSSES",
  "HOT_SOAK", "HOT_SOAK", "HOT_SOAK"
)

# Diurnal  ####
switch(language,
       "portuguese" = cat("\nEmissões evaporativas diurnal\n"),
       "english" = cat("\nEvaporative diurnal emissions\n"),
       "spanish" = cat("\nEmisiones evaporativas diurnal\n")
)

for (i in seq_along(veh_ev)) {
  cat(
    "\n", veh_ev[i],
    rep("", max(nchar(veh_ev) + 1) - nchar(veh_ev[i]))
  )
  
  
  for (j in seq_along(te)) {
    cat(nmonth[j], " ")
    
    # x <- net[[metadata$vehicles[i]]]
    x  <- readRDS(paste0("veh/", veh_ev[i], ".rds"))
    xx <- rowSums(x,na.rm = T)
    
    ef <- ef_cetesb(
      p = ef_d[j],
      veh = veh_ev[i],
      year = year,
      agemax = ncol(x),
      # diurnal: g/day* day/km= g/km
      verbose = verbose
    )[1:40] / (mileage[[veh_ev[i]]] / 365) # mean daily mileage
    
    # muda NaNaN para 0
    ef[is.na(ef)] <- 0
    
    # eff <- weighted.mean(ef, veh[[metadata$vehicles[i]]])
    eff <- weighted.mean(ef, colSums(x,na.rm = T))
    
    emis <- xx*eff*lkm
    
    st <- data.table(id = 1:nrow(net),
                     emis = emis, 
                     pollutant = "NMHC",
                     veh = metadata$vehicles[i],
                     size = metadata$size[i],
                     fuel = metadata$fuel[i],
                     type_emi = "Diurnal",
                     date = as.Date(ISOdate(year, month, 1)))
    fwrite(st, "emi/evaporatives.csv", append = T)
    
  }
}


# Running Losses ####
switch(language,
       "portuguese" = cat("\nEmissões evaporativas running-losses\n"),
       "english" = cat("\nEvaporative running-losses emissions\n"),
       "spanish" = cat("\nEmisiones evaporativas running-loses\n")
)

for (i in seq_along(veh_ev)) {
  cat(
    "\n", veh_ev[i],
    rep("", max(nchar(veh_ev) + 1) - nchar(veh_ev[i]))
  )
  
  
  for (j in seq_along(te)) {
    cat(nmonth[j], " ")
    
    x  <- readRDS(paste0("veh/", veh_ev[i], ".rds"))
    xx <- rowSums(x,na.rm = T)
    
    ef <- ef_cetesb(
      p = ef_rl[j],
      veh = veh_ev[i],
      year = year,
      agemax = ncol(x),
      # g/trip * trip/day * day/km = g/km
      verbose = verbose
    )[1:40] * meta_ev$trips_day[i] / (mileage[[veh_ev[i]]] / 365)
    
    # muda NaNaN para 0
    ef[is.na(ef)] <- 0
    
    # eff <- weighted.mean(ef, veh[[metadata$vehicles[i]]])
    eff <- weighted.mean(ef, colSums(x,na.rm = T))
    
    emis <- xx*eff*lkm
    
    st <- data.table(id = 1:nrow(net),
                     emis = emis, 
                     pollutant = "NMHC",
                     veh = metadata$vehicles[i],
                     size = metadata$size[i],
                     fuel = metadata$fuel[i],
                     type_emi = "Running Losses",
                     date = as.Date(ISOdate(year, month, 1)))
    fwrite(st, "emi/evaporatives.csv", append = T)
    
  }               
}

# Hot Soak ####
switch(language,
       "portuguese" = cat("\nEmissões evaporativas hot-soak\n"),
       "english" = cat("\nEvaporative hot-soak emissions\n"),
       "spanish" = cat("\nEmisiones evaporativas hot-soak\n")
)

for (i in seq_along(veh_ev)) {
  cat(
    "\n", veh_ev[i],
    rep("", max(nchar(veh_ev) + 1) - nchar(veh_ev[i]))
  )
  
  
  for (j in seq_along(te)) {
    cat(nmonth[j], " ")
    
    x  <- readRDS(paste0("veh/", veh_ev[i], ".rds"))
    xx <- rowSums(x,na.rm = T)
    
    ef <- ef_cetesb(
      p = ef_hs[j],
      veh = veh_ev[i],
      year = year,
      agemax = ncol(x),
      verbose = verbose
    )[1:40] * meta_ev$trips_day[i] / (mileage[[veh_ev[i]]] / 365) # quilometragem medio diario
    
    # muda NaNaN para 0
    ef[is.na(ef)] <- 0
    
    
    # eff <- weighted.mean(ef, veh[[metadata$vehicles[i]]])
    eff <- weighted.mean(ef, colSums(x,na.rm = T))
    
    emis <- xx*eff*lkm
    
    st <- data.table(id = 1:nrow(net),
                     emis = emis, 
                     pollutant = "NMHC",
                     veh = metadata$vehicles[i],
                     size = metadata$size[i],
                     fuel = metadata$fuel[i],
                     type_emi = "Hot Soak",
                     date = as.Date(ISOdate(year, month, 1)))
    fwrite(st, "emi/evaporatives.csv", append = T)
  }
}

switch(language,
       "portuguese" = message("\n\nArquivos em: /emi/*:"),
       "english" = message("\nFiles in: /emi/*"),
       "spanish" = message("\nArchivos en: /emi/*")
)


switch(language,
       "portuguese" = message("Limpando..."),
       "english" = message("Cleaning..."),
       "spanish" = message("Limpiando...")
)

suppressWarnings(rm(
  i, mileage, meta_ev, veh_ev, year,
  diurnal_ef, hot_soak_ef, running_losses_ef
))

invisible(gc())
