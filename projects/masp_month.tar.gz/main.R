options(encoding = "UTF-8")
library(vein)                     # vein
library(sf)                       # spatial data
library(cptcity)                  # 7120 colour palettes
library(ggplot2)                  # plots
library(eixport)                  # WRF Chem
library(data.table)               # blasting speed
sessionInfo()

# 0 Configuration
language             <- 'english' # portuguese english spanish  
path                 <- "../inventory.xlsx"
readxl::excel_sheets(path )       # For libre office, readODS::read_ods()
metadata             <- readxl::read_xlsx(path = path, sheet = "metadata")
mileage              <- readxl::read_xlsx(path = path, sheet = "m12")
tfs                  <- readxl::read_xlsx(path = path, sheet = "tfs")
veh                  <- readxl::read_xlsx(path = path, sheet = "fl12")
fuel                 <- readxl::read_xlsx(path = path, sheet = "fuel")
met                  <- readxl::read_xlsx(path = path, sheet = "met_all")
year                 <- 2012
month                <- 1
region               <- 'SP'
theme                <- "black"   # dark clean ink  
scale                <- 'tunnel2018'
delete_directories   <- TRUE
source('config/config.R', encoding = 'UTF-8')

# 1) Network ####
language             <- 'english' # portuguese english spanish 
net                  <- sf::st_read("network/net.gpkg")
crs                  <- 31983
tit                  <- "Vehicular flow [veh/h] in São Paulo"
categories           <- c("pc", "lcv", "trucks", "bus", "mc") # in network/net.gpkg
source('scripts/net.R', encoding = 'UTF-8')

# 2) Traffic ####
language            <- 'english' # portuguese english spanish  
net                 <- readRDS("network/net.rds")
metadata            <- readRDS("config/metadata.rds")
categories          <- c("pc", "lcv", "trucks", "bus", "mc")  # in network/net.gpkg
veh                 <- readRDS("config/fleet_age.rds")
k_D                 <- 1 #/ 0.5254515
k_E                 <- 1 #/ 0.3369715
k_G                 <- 1 #/ 0.2320178
verbose             <- FALSE
year                <- 2012
theme               <- "black"     # dark clean ink  
source('scripts/traffic.R', encoding = 'UTF-8')

# 3) Estimation #### 
language            <- 'english' # portuguese english spanish 
metadata            <- readRDS("config/metadata.rds")
mileage             <- readRDS("config/mileage.rds")
tfs                 <- readRDS("config/tfs.rds")
veh                 <- readRDS("config/fleet_age.rds")
met                 <- readRDS("config/met.rds")
net                 <- readRDS("network/net.rds")
lkm                 <- net$lkm
scale               <- 'tunnel2018'
verbose             <- FALSE
year                <- 2012
month               <- 1

# Fuel eval ####
language            <- 'english' # portuguese english spanish 
fuel                <- readRDS("config/fuel.rds")
pol                 <- "FC"
source('scripts/fuel_eval.R', encoding = 'UTF-8')

# Exhaust
language            <- 'english' # portuguese english spanish 
pol                 <- c("CO", "HC", "NMHC","NOx", "CO2", "SO2", "ETOH",
                         "PM", "NO2", "NO")
sppm                <-  50
source('scripts/exhaust.R', encoding = 'UTF-8')
# source('scripts/exhaust_simple.R', encoding = 'UTF-8')

# Evaporatives
source('scripts/evaporatives.R', encoding = 'UTF-8')
# source('scripts/evaporatives_simple.R', encoding = 'UTF-8')

# ressuspensao gera PM e PM10
language            <- 'english' # portuguese english spanish 
metadata            <- readRDS("config/metadata.rds")
mileage             <- readRDS("config/mileage.rds")
tfs                 <- readRDS("config/tfs.rds")
net                 <- readRDS("network/net.rds")
veh                 <- readRDS("config/fleet_age.rds")
lkm                 <- net$lkm
tf_PC               <- tfs$PC_G
tf_LCV              <- tfs$LCV_G
tf_TRUCKS           <- tfs$TRUCKS_L_D
tf_BUS              <- tfs$BUS_URBAN_D
tf_MC               <- tfs$MC_150_G
sL1                 <- 2.4       # silt [g/m^2] se ADT < 500 (CENMA CHILE) i
sL2                 <- 0.7       # silt [g/m^2] se 500 < ADT < 5000 (CENMA CHILE)
sL3                 <- 0.6       # silt [g/m^2] se 5000 < ADT < 10000 (CENMA CHILE)
sL4                 <- 0.3       # silt [g/m^2] se ADT > 10000 (CENMA CHILE)
# source('scripts/pavedroads.R', encoding = 'UTF-8')
month               <- 1
year                <- 2012
source('scripts/pavedroads.R', encoding = 'UTF-8')
# source('scripts/pavedroads_simple.R', encoding = 'UTF-8')

# 4) Post-estimation #### 
language            <- 'english' # portuguese english spanish 
net                 <- readRDS("network/net.rds")
tfs                 <- readRDS("config/tfs.rds")
pol                 <- c("CO", "HC",  "NOx", "CO2", "SO2","ETOH",
                         "PM", "PM10",
                         "NO2", "NO",
                         "D_NMHC","G_NMHC","E_NMHC",
                         "G_EVAP_01", "E_EVAP_01")  # August
g                   <- eixport::wrf_grid("../wrfinput_d03")
# using grid info from: ../wrfinput_d03 
# Number of lat points 81
# Number of lon points 81
# g                   <- eixport::wrf_grid("wrf/wrfinput_d02")
# g                   <- eixport::wrf_grid("wrf/wrfinput_d01")
crs                 <- 31983
factor_emi          <- 30/(nrow(tfs)/24)    # daily to annual
source('scripts/post.R', encoding = 'UTF-8')
# source('scripts/post_simple.R', encoding = 'UTF-8')

# plots
# language             <- 'english' # portuguese english spanish 
# metadata            <- readRDS("config/metadata.rds")
# tfs                 <- readRDS("config/tfs.rds")
# veh                 <- readRDS("config/fleet_age.rds")
# pol                 <- c("CO", "HC", "NOx", "CO2","PM")
# year                <- 2012
# factor_emi          <- 365               # convertir estimativa diaria a anual
# hours               <- 8
# bg                  <- "white"
# pal                 <- "mpl_viridis"     # procura mais paletas com ?cptcity::find_cpt
# breaks              <- "quantile"        # "sd" "quantile" "pretty"
# tit                 <- "Vehicular emissions in São Paulo [t/ano]"
# source('scripts/plots.R')

# # MECH ####
# language            <- 'english' # portuguese english spanish 
# evap                <- c("G_EVAP_08", "E_EVAP_08")
# g                   <- eixport::wrf_grid("wrf/wrfinput_d03")
# # g                   <- eixport::wrf_grid("wrf/wrfinput_d02")
# # g                   <- eixport::wrf_grid("wrf/wrfinput_d01")
# mech                <- "neu_cb05"        # iag_cb05v2, neu_cb05, iag_racm
# aer                 <- "pmneu2"          # pmiag, pmneu
# source('scripts/mech.R', encoding = 'UTF-8')

# MECH ####
language <- "english" # english spanish
evap     <- c("G_EVAP_01", "E_EVAP_01")
g    <- eixport::wrf_grid("../wrfinput_d03")
pol  <- c("CO", "NO", "NO2", "SO2")
mol  <- c(12, 14 + 16, 14 + 16 * 2, 32 + 16 * 2)
aer  <- "pmneu2"    # pmiag, pmneu
mech <- "CB05opt2"  # "CB4", "CB05", "S99", "S7","CS7", "S7T", "S11", "S11D","S16C","S18B","RADM2", "RACM2","MOZT1"
source("scripts/mech2.R", encoding = "UTF-8")

# file.remove("post/spec_grid/E_ISOP.rds") # remove emissoes biogenicas
file.remove("post/spec_grid/E_BENZENE.rds")

# WRF CHEM
net                 <- readRDS("network/net.rds")
rows                <- 81 # d01 125 / d02 120 / d03 81
cols                <- 81 # d01 125 / d02 128 / d03 81
wrf_times           <- 24 # ?
data("emis_opt")# names(emis_opt)
emis_option <- emis_opt$ecb05_opt2
emis_option[length(emis_option)]<- "E_PM_10"
pasta_wrfinput      <- ".."
pasta_wrfchemi      <- "wrf"
wrfi                <- "../wrfinput_d03"
# wrfi                <- "wrf/wrfinput_d02"
# wrfi                <- "wrf/wrfinput_d01"
domain              <- 3
lt_emissions        <- "2012-07-09 00:00:00" # segunda-feira anterior
hours               <- 0
source('scripts/wrf.R', encoding = 'UTF-8')
