a <- list.files(path = "config", pattern = ".rds", full.names = T)
file.remove(a)
