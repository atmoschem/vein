suppressWarnings(file.remove("emi/wear.csv"))

# Escapamento ####
switch(language,
       "portuguese" = cat("Estimando emissões Wear\n"),
       "english" = cat("Estimating emissions Wear\n"),
       "spanish" = cat("Estimando emisiones Wear\n")
)
metadata_original <- metadata

metadata$v_eea_old <- ifelse(metadata$v_eea_old %in% c("PC", "LCV", "Motorcycle"),
                             metadata$v_eea_old,
                             "HDV")

metadata$v_eea_old <- ifelse(metadata$v_eea_old %in% c("Motorcycle"),
                             "2W",
                             metadata$v_eea_old)


pol <- c("TSP", "PM10", "PM2.5", "PM1",  "PM0.1")

wear <- c("tyre", "break", "road")

pol  <- expand.grid(pol = pol, wear = wear, stringsAsFactors = F)

# Hot Exhaust ####

for (i in seq_along(metadata$vehicles)) {
  
  cat(
    "\n", metadata$vehicles[i],
    rep("", max(nchar(metadata$vehicles) + 1) - nchar(metadata$vehicles[i]))
  )
  
  veh <- readRDS(paste0("veh/", metadata$vehicles[i], ".rds"))
  
  for (j in 1:nrow(pol)) {
    
    cat( pol[j, ]$pol, " ")
    
    
    ef <- ef_wear(wear= pol[j, ]$wear, 
                  type = metadata$v_eea_old[i],
                  pol = pol[j, ]$pol, 
                  speed = speed)
    
    array_x <- emis(
      veh = veh,
      lkm = net$lkm,
      ef = ef,
      profile = tfs[[metadata$vehicles[i]]], 
      fortran = TRUE,
      nt = check_nt() / 2,
      simplify = TRUE,
      verbose = verbose
    )
    
    fwrite(array_x, "emi/wear.csv", append = TRUE)
  }
}


switch(language,
       "portuguese" = message("\nEmissões em: /emi/wear.csv:"),
       "english" = message("\nEmissions in: /emi/wear.csv"),
       "spanish" = message("\nEmisiones en: /emi/wear.csv")
)
