# apagando dados
a <- list.files(path = "config", pattern = ".rds", full.names = T)
file.remove(a)

unlink("csv", recursive = T)
unlink("emi", recursive = T)
unlink("images", recursive = T)
unlink("veh", recursive = T)
unlink("post", recursive = T)
unlink("wrf/wrfchemi_00z_d02")
unlink("wrf/wrfchemi_12z_d02")
unlink(paste0("wrf/", wrfc))

file.remove(".Rhistory")
system("tar -caf brazil_bu.tar.gz .")
system(paste0("mv brazil_bu_v", f, ".tar.gz ~/models/vein/projects/"))
# untar(tarfile = "borrar/curso_brazil.tar.gz", exdir = "curso")

f <- "2020-02-26"
file.remove(".Rhistory")
system(paste0("tar -caf brazil_bu_v", as.character(f), ".tar.gz ."))
if(Sys.info()[["sysname"]] == "Windows") {
stop("Use 7zip")
  } else {
  system(paste0("mv brazil_bu_v", f, ".tar.gz ~/models/vein/projects/"))
}
